module.exports = require('../app/externals/underscore-1.6.0');
