// Contrôleur principal
// ====================

'use strict';

var View = require('./view');

module.exports = View.extend({
  // Le template principal
  template: require('./templates/home')
});
